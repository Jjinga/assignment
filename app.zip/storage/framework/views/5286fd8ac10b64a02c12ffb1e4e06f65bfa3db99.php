<html>
    <head>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
<body>
    
    <span class="p-5"> Welcome </span>
    
    
<h1>layout</h1>
<img src="images/j.jpg" width="30%">
<?php echo $__env->yieldContent('xxx'); ?>;

</body>
</html><?php /**PATH C:\Users\MSCN\myproject1\resources\views/layout.blade.php ENDPATH**/ ?>