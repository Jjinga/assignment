<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" href="images/favicon.ico" />
 
  <script src="//unpkg.com/alpinejs" defer></script>
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body bgcolor="powderblue">
  <nav >
    <a href="/"><img  src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="logo" /></a>
    <ul class="nav nav-pills">
      <?php if(auth()->guard()->check()): ?>
      <li>
        <span >
          Welcome <?php echo e(auth()->user()->name); ?>

        </span>
      </li>
      <li class="active"><a href="/">Home</a></li>
      <li>
        <a href="/listings/manage" > Manage Listings</a>
      </li>
      <li>
        <form class="inline" method="POST" action="/logout">
          <?php echo csrf_field(); ?>
          <button type="submit">
             Logout
          </button>
        </form>
      </li>
      <?php else: ?>
      <li>
        <a href="/register" > Register</a>
      </li>
      <li>
        <a href="/login" > Login</a>
      </li>
      <?php endif; ?>
    </ul>
  </nav>

  <main>
    <?php echo e($slot); ?>

  </main>
  <footer class="w-100 bg-dark text-white mt-24">
    <p class="ml-2">Copyright &copy; 2022, All Rights reserved</p>

    <a href="/listings/create" class="bg-black text-white">Post Job</a>
  </footer>

  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.flash-message','data' => []]); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\Users\MSCN\myproject1\resources\views/components/layout.blade.php ENDPATH**/ ?>