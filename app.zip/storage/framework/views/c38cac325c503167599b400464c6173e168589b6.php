<html>
    <head>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
<body>
    <div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-2 col-lg-2" style="background:#FF6600;padding:10px">  </div>
			<div class="col-sm-12 col-md-8 col-lg-8" style="background:#FF6600;padding:10px"> <span class="ml-5"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.flash-message','data' => []]); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> </span></div>
			<div class="col-sm-12 col-md-2 col-lg-2" style="background:#FF6600;padding:10px">  </div>
			
		</div>
		<div class="row">
			<div class="col-sm-12 col-md-3 col-lg-3" style="background:#E8E8E8">
			<span class="p-5"> Welcome </span>
			</div>  
			
			<div class="col-sm-12 col-md-9 col-lg-9" style="background:#E8E8E8;">
				<div>
				
				
				<?php echo $__env->yieldContent('xxx'); ?>;
			
			</div>
			
					
		</div>
</div>
</body>
</html><?php /**PATH C:\Users\MSCN\myassignment\resources\views/layout.blade.php ENDPATH**/ ?>