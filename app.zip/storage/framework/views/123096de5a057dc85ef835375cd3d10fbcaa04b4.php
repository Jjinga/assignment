
<?php $__env->startSection('xxx'); ?>


<form method="POST" action=" " enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-6">
      <label for="company" class="inline-block text-lg mb-2">Company Name</label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="company"
        value=" " />

 
      <p class="text-red-500 text-xs mt-1">aaa</p>
     
    </div>

    <div class="mb-6">
      <label for="title" class="inline-block text-lg mb-2">Job Title</label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="title"
        placeholder="Example: Senior Laravel Developer" value=" " />

   
      <p class="text-red-500 text-xs mt-1"></p>
  
   

    <div class="mb-6">
      <label for="location" class="inline-block text-lg mb-2">Job Location</label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="location"
        placeholder="Example: Remote, Boston MA, etc" value="" />


      <p class="text-red-500 text-xs mt-1"></p>
   
    </div>

    <div class="mb-6">
      <label for="email" class="inline-block text-lg mb-2">
        Contact Email
      </label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="email" value=" " />

   
      <p class="text-red-500 text-xs mt-1"> </p>
     
    </div>

    <div class="mb-6">
      <label for="website" class="inline-block text-lg mb-2">
        Website/Application URL
      </label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="website"
        value=" " />

     
      <p class="text-red-500 text-xs mt-1"></p>
     
    </div>

    <div class="mb-6">
      <label for="tags" class="inline-block text-lg mb-2">
        Tags (Comma Separated)
      </label>
      <input type="text" class="border border-gray-200 rounded p-2 w-full" name="tags"
        placeholder="Example: Laravel, Backend, Postgres, etc" value=" " />

     
      <p class="text-red-500 text-xs mt-1">zzzz</p>
      
    </div>

    <div class="mb-6">
      <label for="logo" class="inline-block text-lg mb-2">
        Company Logo
      </label>
      <input type="file" class="border border-gray-200 rounded p-2 w-full" name="logo" />

    
      <p class="text-red-500 text-xs mt-1"></p>
      
    </div>

    <div class="mb-6">
      <label for="description" class="inline-block text-lg mb-2">
        Job Description
      </label>
      <textarea class="border border-gray-200 rounded p-2 w-full" name="description" rows="10" placeholder="Include tasks, requirements, salary, etc"></textarea>

      
      <p class="text-red-500 text-xs mt-1"></p>
      
    </div>

    <div class="mb-6">
      <button class="bg-laravel text-white rounded py-2 px-4 hover:bg-black">
        Create Gig
      </button>

      <a href="/" class="text-black ml-4"> Back </a>
    </div>
  </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSCN\myproject1\resources\views/Listings/create.blade.php ENDPATH**/ ?>