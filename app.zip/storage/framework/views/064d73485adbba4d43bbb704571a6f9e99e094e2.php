<div <?php echo e($attributes->merge(['class'=>'m-3 p-5 text-default bg-warning border border-gray-500 rounded p-6'])); ?> >
<?php echo e($slot); ?>

</div><?php /**PATH C:\Users\MSCN\myproject1\resources\views/components/blackdiv.blade.php ENDPATH**/ ?>