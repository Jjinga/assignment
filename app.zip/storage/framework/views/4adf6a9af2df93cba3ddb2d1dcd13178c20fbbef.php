<?php $__env->startSection('xxx'); ?>


<div class="m-5 max-auto">
<img src="images/j.jpg" width="50%" class="mb-2">
<h1><span class="p-5">Enter Stock Details</span></h1>
<form method="POST" action="/create" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
       <div class="m-2">
		  <label for="pdname" class="w-50 text-center"><b>Product Name</b></label>
		  <input type="text" class="form-control w-50" name="pdname"
			placeholder="Product Name" value="<?php echo e(old('pdname')); ?>" />

	   
			<?php $__errorArgs = ['pdname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<p class="alert alert-danger"><?php echo e($message); ?></p>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		
		 <div class="m-2">
		  <label for="qty"  class="w-50 text-center"><b>Quantity</b></label>
		  <input type="text" class="form-control w-50" name="qty"
			placeholder="Quantity" value="<?php echo e(old('pdname')); ?>" />

	   
			<?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<p class="alert alert-danger"><?php echo e($message); ?></p>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		       
			   
		<div class="m-2">
		  <label for="price"  class="w-50 text-center"><b>Price</b></label>
		  <input type="text" class="form-control w-50" name="price"
			placeholder="Price" value="<?php echo e(old('price')); ?>" />

	   
			<?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<p class="alert alert-danger"><?php echo e($message); ?></p>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>

    <div >
      <button class="btn btn-primary mt-5 w-50">
        Save Record
      </button>
    </div>
  </form>
</div>
  <?php $__env->stopSection(); ?>







<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coalitiontest.local\myassignment\resources\views/startfolder/index.blade.php ENDPATH**/ ?>