<div <?php echo e($attributes->merge(['class' => 'bg-default text-dark'])); ?>>
  <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\MSCN\myproject1\resources\views/components/card.blade.php ENDPATH**/ ?>