
<?php if (! (count($listings)==0)): ?>
<?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1>
    <?php echo e($listing['title']); ?>

</h1>
<h3>
    <?php echo e($listing['description']); ?>

</h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h3>No listings found</h3>
<?php endif; ?><?php /**PATH C:\Users\MSCN\myproject1\resources\views/listing.blade.php ENDPATH**/ ?>