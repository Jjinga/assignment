<?php if(session()->has('message')): ?>
<p class="alert alert-success mt-0"> <?php echo e(session('message')); ?></p>
<?php endif; ?><?php /**PATH C:\Users\MSCN\myproject1\resources\views/components/flash-message.blade.php ENDPATH**/ ?>