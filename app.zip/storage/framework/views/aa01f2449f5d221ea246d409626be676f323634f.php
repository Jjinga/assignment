
<img class="" src="<?php echo e($listing->logo ? asset('storage/'. $listing->logo) : asset('/images/no-image.png')); ?>" alt="" />
<h1>
    <?php echo e($listing['title']); ?>

</h1>
<h3>
    <?php echo e($listing['description']); ?>

</h3>

    <a href="/listings/<?php echo e($listing->id); ?>/edit">
      <i class="fa-solid fa-pencil"></i> Edit
    </a>

    <form method="POST" action="/listings/<?php echo e($listing->id); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button > Delete</button>
    </form>

  <?php /**PATH C:\Users\MSCN\myproject1\resources\views/singlelisting.blade.php ENDPATH**/ ?>