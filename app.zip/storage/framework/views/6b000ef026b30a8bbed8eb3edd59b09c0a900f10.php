<?php if(session()->has('message')): ?>
<p class="alert alert-success mt-0"> <?php echo e(session('message')); ?> <a target="new" href="/storage/stock.json"><b>You may Click here to view it</b></a></p>
<?php endif; ?><?php /**PATH C:\Users\MSCN\myassignment\resources\views/components/flash-message.blade.php ENDPATH**/ ?>